create definer = root@`%` trigger after_person_insert
    after insert
    on person
    for each row
BEGIN
    INSERT INTO pet (pet_name, person_id)
    VALUES (CONCAT(NEW.name, ' dog'), NEW.id);
END;

